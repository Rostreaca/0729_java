package com.kh.hw.member.controller;

import com.kh.hw.member.model.vo.Member;

public class MemberController {
	
	private Member[] m = new Member[SIZE];
	public static int SIZE = 10; 
	
	public int existMemberNum() {
		return 0;
	}
	public Boolean checkId(String inputId) {
		return false;
	}
	public void insertMember(String id, String name, String password, String email, String gender, int age) {
		
	}
	public String searchId(String id) {
		return null;
	}
	public Member[] searchName(String name) {
		return null;
	}
	public Member[] searchEmail(String email) {
		return null;
	}
	
	
	
}
